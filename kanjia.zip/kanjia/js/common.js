﻿function backPage() {
    window.history.back(-1);
}